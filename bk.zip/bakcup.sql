/*
SQLyog Professional v13.1.1 (64 bit)
MySQL - 8.0.30 : Database - laravel-boilerplate-api
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`laravel-boilerplate-api` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `laravel-boilerplate-api`;

/*Table structure for table `comments` */

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `comments` */

insert  into `comments`(`id`,`created_at`,`updated_at`,`name`,`text`) values 
(1,'2024-01-27 10:39:36','2024-01-27 10:39:36','Prof. Alvah Thompson I','Eius nihil laboriosam repellendus enim nam. Totam explicabo laudantium repudiandae quo. Et quia blanditiis quidem labore facilis nam.'),
(2,'2024-01-27 10:39:36','2024-01-27 10:39:36','Reynold Schumm','Vero velit debitis harum quo dolores in. Neque voluptas ea sed accusamus. Aliquid incidunt praesentium aut est.'),
(3,'2024-01-27 10:39:36','2024-01-27 10:39:36','Naomi Kemmer','Veniam veniam et vero dicta numquam qui. Aut ea deserunt quisquam sed. Temporibus vero quasi impedit nobis. Illo repudiandae quia et officia nihil excepturi rem. Ut eum nihil dolores atque et nobis.');

/*Table structure for table `configurations` */

DROP TABLE IF EXISTS `configurations`;

CREATE TABLE `configurations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `input_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editable` tinyint NOT NULL DEFAULT '1',
  `weight` int DEFAULT NULL,
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `order` int NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `configurations` */

insert  into `configurations`(`id`,`name`,`value`,`title`,`description`,`input_type`,`editable`,`weight`,`params`,`order`,`type`) values 
(1,'title','W3CMS Laravel',NULL,NULL,'text',1,1,NULL,0,'site'),
(2,'tagline','W3CMS Laravel System',NULL,NULL,'textarea',1,2,NULL,3,'site'),
(3,'email','ali_naeem89@live.com',NULL,NULL,'text',1,3,NULL,2,'site'),
(4,'status','1',NULL,NULL,'checkbox',1,4,NULL,4,'site'),
(5,'copyright','Crafted with <span class=\"heart\"></span> by <a href=\"https://www.w3itexperts.com/\\\" target=\\\"_blank\\\">W3ITEXPERTS</a>','Copyright Text',NULL,'text',1,5,NULL,5,'site'),
(6,'footer_text','Developed by <a href=\"https://www.w3itexperts.com/\\\" target=\\\"_blank\\\">W3itexperts</a>','Footer text',NULL,'textarea',1,6,NULL,6,'site'),
(7,'coming_soon','0',NULL,NULL,'checkbox',1,7,NULL,7,'site'),
(8,'contact','1234567890',NULL,NULL,'text',1,8,NULL,8,'site'),
(9,'logo','1673435349.logo-full-black.png','Logo','Site Logo','file',1,9,NULL,9,'site'),
(10,'favicon','1673435350.favicon.png','Site Favicon','Site Favicon','file',1,10,NULL,10,'site'),
(11,'maintenance_message','PLEASE SORRY FOR THE <span class=\"text-primary\">DISTURBANCES</span>','Maintenance Message','Site down for maintenance Message will show on maintenance page','textarea',1,11,NULL,13,'site'),
(12,'comingsoon_message','We Are Coming Soon !','Coming Soon Message','Coming soon message will show on coming soon page','textarea',1,12,NULL,11,'site'),
(13,'text_logo','1673435350.logo-text.png','Text Logo',NULL,'file',1,13,NULL,12,'site'),
(17,'instagram','https://www.instagram.com/','Instagram Url',NULL,'text',1,17,NULL,17,'social'),
(18,'linkedin','https://www.in.linkedin.com/','Whatsapp Url',NULL,'text',1,17,NULL,17,'social'),
(19,'facebook','http://www.facebook.com','Facebook Url',NULL,'text',1,18,NULL,18,'social'),
(20,'twitter','http://www.twitter.com','Twitter Url',NULL,'text',1,19,NULL,19,'social'),
(21,'menu_location','a:5:{s:7:\"primary\";a:2:{s:5:\"title\";s:23:\"Desktop Horizontal Menu\";s:4:\"menu\";s:1:\"1\";}s:8:\"expanded\";a:2:{s:5:\"title\";s:21:\"Desktop Expanded Menu\";s:4:\"menu\";s:1:\"3\";}s:6:\"mobile\";a:2:{s:5:\"title\";s:11:\"Mobile Menu\";s:4:\"menu\";N;}s:6:\"footer\";a:2:{s:5:\"title\";s:11:\"Footer Menu\";s:4:\"menu\";s:1:\"2\";}s:6:\"social\";a:2:{s:5:\"title\";s:11:\"Social Menu\";s:4:\"menu\";s:0:\"\";}}',NULL,NULL,'text',0,20,NULL,20,'site'),
(24,'registeration_email','1',NULL,NULL,'textarea',1,NULL,'1',0,'email'),
(25,'password_reset_email','1',NULL,NULL,'textarea',1,NULL,'1',0,'email'),
(26,'login_notification_email','1',NULL,'','textarea',1,NULL,'1',0,'email'),
(30,'comingsoon_date','2023-02-27',NULL,'','date',1,NULL,'',0,'site'),
(31,'biography','A Wonderful Serenity Has Taken Possession Of My Entire Soul, Like These.',NULL,'','text',1,NULL,'',0,'site'),
(32,'location','832  Thompson Drive, San Fransisco CA 94107, United States',NULL,'','text',1,NULL,'',0,'site'),
(33,'office_time','Time 09:00 AM To 07:00 PM',NULL,'Ex. : \"Time 06:00 AM To 08:00 PM\'','text',1,NULL,'',0,'site'),
(34,'icon_logo','1673520377.image_2023_01_02T08_30_32_811Z.png',NULL,'','file',1,NULL,'',0,'site');

/*Table structure for table `failed_jobs` */

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `failed_jobs` */

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values 
(1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_reset_tokens_table',1),
(3,'2019_08_19_000000_create_failed_jobs_table',1),
(4,'2019_12_14_000001_create_personal_access_tokens_table',1),
(5,'2024_01_27_103637_create_comments_table',1),
(6,'2024_01_27_180805_create_permission_tables',2),
(9,'2024_02_21_061709_create_configurations_table',4),
(11,'2024_02_29_212502_add_col_type_to_configurations_table',5),
(13,'2024_02_29_202445_create_pages_table',6),
(14,'2024_03_13_162507_add_cols_to_permissions_table',7),
(15,'2024_03_13_164227_add_cols_deny_to_model_has_permissions_table',8);

/*Table structure for table `model_has_permissions` */

DROP TABLE IF EXISTS `model_has_permissions`;

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `deny` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `model_has_permissions` */

/*Table structure for table `model_has_roles` */

DROP TABLE IF EXISTS `model_has_roles`;

CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `model_has_roles` */

insert  into `model_has_roles`(`role_id`,`model_type`,`model_id`) values 
(16,'App\\Models\\User',12),
(17,'App\\Models\\User',18),
(20,'App\\Models\\User',21);

/*Table structure for table `pages` */

DROP TABLE IF EXISTS `pages`;

CREATE TABLE `pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `banner` text COLLATE utf8mb4_unicode_ci,
  `auther` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `pages` */

insert  into `pages`(`id`,`title`,`description`,`banner`,`auther`,`created_at`,`updated_at`) values 
(1,'Test page','Page Description','public/images/xCj2IcZGJs2r735su1eHBq6l7EbWtdbkXayHimKP.png','Ali Baig','2024-03-02 08:37:50','2024-03-02 08:37:50');

/*Table structure for table `password_reset_tokens` */

DROP TABLE IF EXISTS `password_reset_tokens`;

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `password_reset_tokens` */

/*Table structure for table `permissions` */

DROP TABLE IF EXISTS `permissions`;

CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `temp_permission_id` bigint unsigned DEFAULT NULL,
  `action` text COLLATE utf8mb4_unicode_ci,
  `type` enum('pre-define','user-define') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user-define',
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `permissions` */

insert  into `permissions`(`id`,`name`,`guard_name`,`created_at`,`updated_at`,`temp_permission_id`,`action`,`type`) values 
(1,'users-create','sanctum',NULL,NULL,NULL,'Controllers/UserController@create','user-define'),
(2,'users-edit','sanctum',NULL,NULL,NULL,'Controllers/UserController@edit','user-define'),
(3,'users-delete','sanctum',NULL,NULL,NULL,'Controllers/UserController@destroy','user-define'),
(4,'users-view','sanctum',NULL,NULL,NULL,'Controllers/UserController@index','user-define'),
(6,'roles-create','sanctum',NULL,NULL,NULL,'Controllers/RoleController@create','user-define'),
(7,'roles-edit','sanctum',NULL,NULL,NULL,'Controllers/RoleController@edit','user-define'),
(8,'roles-delete','sanctum',NULL,NULL,NULL,'Controllers/RoleController@destroy','user-define'),
(9,'roles-view','sanctum',NULL,NULL,NULL,'Controllers/RoleController@index','user-define'),
(10,'permissions-create','sanctum',NULL,NULL,NULL,'Controllers/PermissionController@create','user-define'),
(11,'permissions-edit','sanctum',NULL,NULL,NULL,'Controllers/PermissionController@edit','user-define'),
(12,'permissions-delete','sanctum',NULL,NULL,NULL,'Controllers/PermissionController@destroy','user-define'),
(13,'permissions-view','sanctum',NULL,NULL,NULL,'Controllers/PermissionController@index','user-define'),
(14,'configurations-create','sanctum',NULL,'2024-02-29 18:09:40',NULL,'Controllers/ConfigurationController@index','user-define'),
(15,'configurations-delete','sanctum',NULL,'2024-02-29 18:09:40',NULL,'Controllers/ConfigurationController@destroy','user-define'),
(16,'configurations-edit','sanctum',NULL,'2024-02-29 18:09:40',NULL,'Controllers/ConfigurationController@edit','user-define'),
(17,'configurations-view','sanctum',NULL,'2024-02-29 18:09:40',NULL,'Controllers/ConfigurationController@index','user-define'),
(18,'comments-create','sanctum',NULL,NULL,NULL,'Controllers/CommentController@create','user-define'),
(19,'comments-delete','sanctum',NULL,NULL,NULL,'Controllers/CommentController@destroy','user-define'),
(20,'comments-edit','sanctum',NULL,NULL,NULL,'Controllers/CommentController@edit','user-define'),
(21,'comments-view','sanctum',NULL,NULL,NULL,'Controllers/CommentController@index','user-define'),
(56,'pages-create','sanctum','2024-03-08 04:47:15','2024-03-08 04:47:15',NULL,'Controllers/PageController@create','user-define'),
(57,'pages-edit','sanctum','2024-03-08 04:47:15','2024-03-08 04:47:15',NULL,'Controllers/PageController@edit','user-define'),
(58,'pages-delete','sanctum','2024-03-08 04:47:15','2024-03-08 04:47:15',NULL,'Controllers/PageController@destroy','user-define'),
(59,'pages-view','sanctum','2024-03-08 04:47:15','2024-03-08 04:47:15',NULL,'Controllers/PageController@index','user-define'),
(60,'auth-logout','sanctum',NULL,NULL,NULL,'Controllers/AuthController@logout','user-define');

/*Table structure for table `personal_access_tokens` */

DROP TABLE IF EXISTS `personal_access_tokens`;

CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `personal_access_tokens` */

/*Table structure for table `role_has_permissions` */

DROP TABLE IF EXISTS `role_has_permissions`;

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `role_has_permissions` */

insert  into `role_has_permissions`(`permission_id`,`role_id`) values 
(1,17),
(2,17),
(3,17),
(4,17),
(6,17),
(7,17),
(8,17),
(9,17),
(10,17),
(11,17),
(12,17),
(13,17),
(14,17),
(15,17),
(16,17),
(17,17),
(18,17),
(19,17),
(20,17),
(21,17),
(56,17),
(57,17),
(58,17),
(59,17),
(60,17),
(1,20),
(2,20),
(3,20),
(4,20),
(56,20),
(57,20),
(58,20),
(59,20),
(60,20);

/*Table structure for table `roles` */

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `roles` */

insert  into `roles`(`id`,`name`,`guard_name`,`created_at`,`updated_at`) values 
(16,'Super Admin','sanctum','2024-01-27 21:34:52','2024-01-27 21:34:52'),
(17,'Admin','sanctum','2024-01-28 07:04:51','2024-01-28 07:04:51'),
(20,'Manager','sanctum','2024-02-22 21:38:08','2024-02-22 21:38:08'),
(21,'Branch Manager','sanctum','2024-02-25 20:50:53','2024-02-25 20:50:53'),
(26,'Test Test','sanctum','2024-03-03 19:48:49','2024-03-03 19:48:49');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`email`,`email_verified_at`,`password`,`remember_token`,`created_at`,`updated_at`) values 
(12,'Ali Baig','ali_naeem89@live.com',NULL,'$2y$12$eOO0nSUZ/9Q7R63Rn5Ofhu7vdpiFjviPnf8wpGKR3tKeT4l0XkUea',NULL,'2024-01-28 06:38:57','2024-01-28 06:38:57'),
(18,'Wajid Asim','wajid@gmail.com',NULL,'$2y$12$wPa4cUz2AWQ7fp2ScQGpOOSTzzmY3mjvOyxoR7kV3tiI5qLAzemze',NULL,'2024-02-22 16:09:34','2024-02-22 16:09:34'),
(21,'Manager Sahab','manager@live.com',NULL,'$2y$12$rsXHy66tL2Towv5nC7hprOC9ut8Yugxs56fsLhof1CCXn1OP8fawm',NULL,'2024-03-06 04:39:51','2024-03-06 04:39:51');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
