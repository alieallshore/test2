<?php

namespace App\Http\Controllers;

use App\Services\PageService;
use Illuminate\Http\Request;

class PageController extends Controller
{

    protected $page = null;

    public function __construct(PageService $pageService){
        $this->page = $pageService;
        // $this->middleware('permission:pages-view|pages-list|pages-create|pages-edit|pages-delete', ['only' => ['index','show']]);
        // $this->middleware('permission:pages-create', ['only' => ['create','store']]);
        // $this->middleware('permission:pages-edit', ['only' => ['edit','update']]);
        // $this->middleware('permission:pages-delete', ['only' => ['destroy']]);
        // $this->middleware('permission:pages-view', ['only' => ['view']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $id = null, $model = 'App\Models\Page') {

        return $this->page->pageIndex($request, $id, $model);
    }

    public function create(Request $request)
    {
        // Only to View ROle Create.
    }

    public function store(Request $request, $id = null, $model = 'App\Models\Page')
    {        
        return $this->page->pageStore($request, $id, $model);
    }

    public function show(Request $request, $id = null, $model = 'App\Models\Page')
    {
        return $this->page->pageShow($request, $id, $model);
    }

    public function update(Request $request, $id = null, $model = 'App\Models\Page')
    {
       return $this->page->pageUpdate($request, $id, $model);
    }

    public function destroy(Request $request, $id = null, $model = 'App\Models\Page')
    {        
        return $this->page->pageDestroy($request, $id, $model);
    }
}
