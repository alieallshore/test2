<?php

namespace App\Http\Controllers;

use App\Services\ConfigurationService;
use Illuminate\Http\Request;

class ConfigurationController extends Controller
{

    protected $configurations = null;

    public function __construct(ConfigurationService $configurations){
        $this->configurations = $configurations;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request, $id = null, $model = '\App\Models\Configuration')
    {
        return $this->configurations->configurationIndex($request, $id, $model);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        return $this->configurations->configurationStore($request);
    }
    /**
     * Show the form for editing the specified resource.
     */
    public function show($id)
    {
        return $this->configurations->configurationShow($id);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        return $this->configurations->configurationUpdate($request, $id);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        return $this->configurations->configurationDestroy($id);
    }
}
